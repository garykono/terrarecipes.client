export default function Footer() {
    return <div className="footer"></div>
}