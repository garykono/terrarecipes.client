export default function LoadingScreen() {
    return (
        <div id="loader">
            <div className="spinner"></div>
        </div>
    );
}