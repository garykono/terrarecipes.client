import { Params } from "react-router";

export interface BrowseLoaderResult {

}

export async function browseLoader(): Promise<BrowseLoaderResult> {
    return {
    }
}